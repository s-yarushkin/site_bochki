// Existing calculator and model pages retain their event/API entry points.
export {openPlan} from './r94-layouts.mjs?v=all-forms-20261105';
